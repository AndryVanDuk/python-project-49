# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games_1', 'brain_games_1.game', 'brain_games_1.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games_1.scripts.brain_calc:main',
                     'brain-even = brain_games_1.scripts.brain_even:main',
                     'brain-games = brain_games_1.scripts.brain_games:main',
                     'brain-gcd = brain_games_1.scripts.brain_gcd:main',
                     'brain-prime = brain_games_1.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games_1.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '## Brain Games: the collection of 5 math mini-games\n<hr>\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AndryVanDuk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AndryVanDuk/python-project-49/actions) \n[![Maintainability](https://api.codeclimate.com/v1/badges/9a62c14fcac3cf24eddb/maintainability)](https://codeclimate.com/github/AndryVanDuk/python-project-49/maintainability)\n\nThis is project ["Brain Games"](https://ru.hexlet.io/programs/python/projects/49) on the Python Development course on [Hexlet.io](https://ru.hexlet.io/programs/python)\n\n### Used technologies:\n![](https://img.shields.io/badge/language-python-blue)\n![](https://img.shields.io/badge/lybrary-prompt-brightgreen)\n![](https://img.shields.io/badge/lybrary-random-orange)\n![](https://img.shields.io/badge/lybrary-math-ff67b4)\n\nThis project was built using these tools:\n\n| Tool                                                                        | Description                                             |\n|-----------------------------------------------------------------------------|---------------------------------------------------------|\n| [poetry](https://poetry.eustace.io/)                                        | "Python dependency management and packaging made easy"  |\n| [Py.Test](https://pytest.org)                                               | "A mature full-featured Python testing tool"            |\n| [wemake-python-styleguide](https://wemake-python-stylegui.de)               | "the strictest and most opinionated python linter ever" |\n\n---\n## Install\n```\ngit clone https://github.com/AndryVanDuk/python-project-49.git\ncd python-project-49\nmake package-install\n```\n\n### Description:\n\n**"Mind Games"** is a set of five console games based on the popular mobile brain-pumping apps. Each game asks questions that need to be answered correctly. After three correct answers, the game is considered completed. Incorrect answers end the game and prompt you to play it again. \n\nGames:\n\n* __Brain Even__ (Answer __"yes"__ if the number is even, otherwise answer __"no"__)\n* __<g>Brain Calculator__ (Answer what is the result of the expression?)\n* __Brain GCD__ (Answer what is the greatest common divisor of given numbers)\n* __Brain Progression__ (Answer what number is missing in the progression?)\n* __Brain Prime__ (Answer "yes" if given number is prime, otherwise answer "no")\n\nThey are launched with simple commands:*\n```commandline\nbrain-even\nbrain-calc\nbrain-gcd\nbrain-progression\nbrain-prime\n```\n:pencil2:*_Make sure that you have Python version 3.6 or higher installed._\n\n\n### Game: "Is even?"\nThe essence of the game is as follows: the user is shown a random number.\nAnd he needs to answer \'yes\' if the number is even, or \'no\' if it is odd:\n[![asciicast](https://asciinema.org/a/561485.svg)](https://asciinema.org/a/561485)\n\n\n### Game: "Calculator"\nThe essence of the game is as follows: the user is shown a random mathematical\nexpression that needs to be calculated and written down the correct answer.\n[![asciicast](https://asciinema.org/a/561486.svg)](https://asciinema.org/a/561486)\n\n### Game: "GCD" \nThe essence of the game is as follows: the user shows two random numbers, for example,\n25 50. The user must calculate and introduce the largest total divider of these numbers.\n[![asciicast](https://asciinema.org/a/565155.svg)](https://asciinema.org/a/565155)\n\n### Game: "Progression"\nThe essence of the game is as follows: the user is shown a series of numbers, forming an\narithmetic progression, replacing any of the numbers with two dots. The player must determine this number.\n[![asciicast](https://asciinema.org/a/565973.svg)](https://asciinema.org/a/565973)\n\n\n### Game: ""\n\n### Good luck and have a fun game! 🤚',
    'author': 'Andrey Bezkorovaynyi',
    'author_email': 'duhasmok@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
